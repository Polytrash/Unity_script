#ifndef _OBJECT_SCATTER_H
#define _OBJECT_SCATTER_H

#include "api_macros.h"

// richMove

#include <maya/MArgList.h>
#include <maya/MDagPath.h>
#include <maya/MGlobal.h>
#include <maya/MMatrix.h>
#include <maya/MPlane.h>
#include <maya/MRichSelection.h>
#include <maya/MSelectionList.h>
#include <maya/MVector.h>
#include <maya/MWeight.h>

#include <maya/MPxCommand.h>
#include <maya/MPxNode.h>
#include <maya/MPxToolCommand.h>

#include <maya/MFnNumericAttribute.h>
#include <maya/MFnTransform.h>

#include <maya/MItGeometry.h>
#include <maya/MItSelectionList.h>

// randomizerDevice

#include <stdlib.h>

#include <maya/MPlug.h>

#include <maya/MFnPlugin.h>
#include <maya/MTypeId.h>

#include <maya/MIOStream.h>

#include <maya/MDataBlock.h>
#include <maya/MPxThreadedDeviceNode.h>

class ObjectScatter : public MPxThreadedDeviceNode
{
public:

						 ObjectScatter();
		virtual			~ObjectScatter();

		virtual void	postConstructor();	// randomizerDevice

		virtual MStatus compute( const MPlug& plug, MDataBlock& data);
		virtual void	threadHandler();			// randomizerDevice
		virtual void	threadShutdownHandler();	// randomizerDevice

		static void*	creator();
		static MStatus  initialize();


		MStatus doIt( const MArgList& args);
		MStatus redoIt();
		MStatus undoIt();
		MStatus finalize();

		static MObject outputTranslate;		// randomizerDevice
		static MObject outputTranslateX;	// randomizerDevice
		static MObject outputTranslateY;	// randomizerDevice
		static MObject outputTranslateZ;	// randomizerDevice

		static MTypeId id;					// randomizerDevice


		inline bool isUndoable() const;

		void setVector(double x, double y, double z);



private:

		MVector delta;	// �f���^�x�N�g��
		MStatus action(int flag);// �����̓��e

};





#endif _OBJECT_SCATTER_H



