#include "objectScatter.h"

// ���s���@ objectScatter (1, 1, 1)

MStatus initializePlugin( MObject obj)
{
	MStatus status;

	MFnPlugin plugin(obj, "Shinichi Muraoka", "1.0", "Any");

		status = plugin.registerNode("ObjectScatter", ObjectScatter::id, ObjectScatter::creator, ObjectScatter::initialize, MPxNode::kThreadedDeviceNode);

	if( !status){
		status.perror("failed to registerNode ObjectScatterNode");
	}
		return status;
	
}


MStatus uninitializePlugin(MObject obj)
{
	MStatus status;

	MFnPlugin plugin(obj);
	
	status = plugin.deregisterNode(ObjectScatter::id);
	if(!status){
		status.perror("failed to registerNode ObjectScatterNode");

	}

	return status;
}
